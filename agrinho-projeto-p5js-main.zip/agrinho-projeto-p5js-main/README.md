Projeto "Jardineiro Virtual"
Este projeto foi desenvolvido utilizando a biblioteca p5.js para criar um jogo interativo e educativo.
Como jogar:
Movimentações: use as setas do teclado.
Para plantar: aperte a tecla P ou espaço.
Para ir para o proximo nivel aperte N, se quiser reiniciar, aperte R.
Oque fazer com os pontos: aperte no nome loja e use seus pontos a vontade.
